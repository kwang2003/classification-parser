insert into classification(id,name,level,parent_id,status) values('11','其他矿产品',1,'null',1);
insert into classification(id,name,level,parent_id,status) values('1101','地热',2,'11',1);
insert into classification(id,name,level,parent_id,status) values('1102','天然水',2,'11',1);
insert into classification(id,name,level,parent_id,status) values('1199','其他未列明矿产品',2,'11',1);
